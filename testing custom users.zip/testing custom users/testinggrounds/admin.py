from atexit import register
from django.contrib import admin
from .models import *
from django.contrib.auth.admin import UserAdmin
# Register your models here.
from django.contrib.auth import forms as auth_forms

#UserAdmin.fieldsets = ('Custom fields set', {'fields': ('email', 'username', 'is_admin', 'is_customer', 'is_staff','is_airline')})
ADDITIONAL_USER_FIELDS = (
    (None, {'fields': ('email','is_admin', 'is_customer', 'is_airline')}),
)
class UserChangeForm(auth_forms.UserChangeForm):
    class Meta(auth_forms.UserChangeForm.Meta):
        model = Account


class UserCreationForm(auth_forms.UserCreationForm):
    class Meta(auth_forms.UserCreationForm.Meta):
        model = Account
        fields = ("username", "email")

class AccountAdmin(UserAdmin):
    list_display = ['email', 'username', 'date_joined', 'last_login', 'is_admin', 'is_customer', 'is_airline']
    search_fields = ['email', 'username', 'date_joined']
    readonly_fields = ['date_joined', 'last_login']
    add_fieldsets = UserAdmin.add_fieldsets + ADDITIONAL_USER_FIELDS


    filter_horizontal =()
    list_filter = ()
    fieldsets = (UserAdmin.add_fieldsets + ADDITIONAL_USER_FIELDS)
admin.site.register(Account, AccountAdmin)

@admin.register(Country)
class CountryAdmin(admin.ModelAdmin):
    list_display = ['country_name', 'flag', 'link']
    list_display_links = ('link',)
    list_editable = ['flag']

@admin.register(Airline)
class AirlineAdmin(admin.ModelAdmin):
    list_display = ['name', 'user', 'country']

@admin.register(Flight)
class FlightAdmin(admin.ModelAdmin):
    list_display = ['airline', 'origin_country', 'destination_country', 'departure_time', 'landing_time', 'remaining_tickets']

@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    list_display =['user' , 'first_name' , 'last_name']